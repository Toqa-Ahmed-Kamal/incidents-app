// src/App.jsx
import React, { useEffect, useRef, useState } from "react";
import IncidentsMap from "./components/IncidentsMap";
import IncidentsList from "./components/IncidentsList";
import AddIncident from "./components/AddIncident";
import { Routes, Route, Link, Navigate } from "react-router-dom";
import HomePage from "./pages/HomePage";


// Firebase Auth
import {
  auth,
  onAuthStateChanged,
  signInWithPopup,
  signOut,
  googleProvider,
  githubProvider,
} from "./firebase";

export default function App() {
  const mapRef = useRef(null);

  // Filters/Sorting (لو لسه ما نقلتهاش جوه IncidentsList، سيبها مؤقتًا هنا)
  const [severityFilter, setSeverityFilter] = useState(0);
  const [sortBy, setSortBy] = useState("createdAt_desc");

  // Pick on map
  const [pickMode, setPickMode] = useState(false);
  const [pickedLocation, setPickedLocation] = useState(null);

  // Auth state
  const [user, setUser] = useState(null);
  const [authLoading, setAuthLoading] = useState(true);

  // Listen to auth state
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (u) => {
      setUser(u);
      setAuthLoading(false);
    });
    return () => unsub();
  }, []);

  // Login / Logout handlers
  const loginWithGoogle = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (e) {
      console.error(e);
      alert("Google login failed");
    }
  };
  const loginWithGitHub = async () => {
    try {
      await signInWithPopup(auth, githubProvider);
    } catch (e) {
      console.error(e);
      alert("GitHub login failed");
    }
  };
  const logout = async () => {
    try {
      await signOut(auth);
    } catch (e) {
      console.error(e);
    }
  };

  function handleRequestPickOnMap() {
    setPickedLocation(null);
    setPickMode(true);
  }

  function handleMapPicked(coords) {
    setPickedLocation(coords);
    setPickMode(false);
    if (mapRef.current && typeof mapRef.current.setView === "function") {
      try {
        mapRef.current.setView([coords.lat, coords.lng], 15);
      } catch {}
    }
  }

  // مهم: الدالة دي كانت ناقصة
  function handleSelectIncident(incident) {
    if (!incident?.location) return;
    const { lat, lng } = incident.location;
    if (mapRef.current && typeof mapRef.current.setView === "function") {
      try {
        mapRef.current.setView([lat, lng], 16);
      } catch {}
    }
  }
const RequireAuth = ({ children }) => {
  if (authLoading) return <div className="p-3 small text-muted">...</div>;
  if (!user) return <Navigate to="/register" replace />;
  return children;
};
const RedirectIfAuthed = ({ children }) => {
  if (authLoading) return <div className="p-3 small text-muted">...</div>;
  if (user) return <Navigate to="/" replace />;
  return children;
};

  return (
    <div className="bg-light" style={{ minHeight: "100vh" }}>
<nav className="navbar bg-white border-bottom" style={{ height: 64 }}>
  <div className="container-fluid d-flex justify-content-between">
    <Link to="/" className="navbar-brand mb-0 h1 text-decoration-none">Incidents Map</Link>

    {authLoading ? (
      <span className="small text-muted">...</span>
    ) : user ? (
      <div className="d-flex align-items-center gap-2">
        {user.photoURL ? (
          <img src={user.photoURL} alt="" width={26} height={26} style={{ borderRadius: "50%" }} />
        ) : null}
        <span className="small">{user.displayName || user.email}</span>
        <button className="btn btn-sm btn-outline-danger" onClick={logout}>Logout</button>
      </div>
    ) : (
      <div className="d-flex gap-2">
        <Link className="btn btn-sm btn-primary" to="/register">Register</Link>
        <Link className="btn btn-sm btn-outline-secondary" to="/login">Login</Link>
      </div>
    )}
  </div>
</nav>

<Routes>
  <Route
    path="/"
    element={
      <RequireAuth>
        <HomePage user={user} />
      </RequireAuth>
    }
  />
  <Route
    path="/register"
    element={
      <RedirectIfAuthed>
        <Register />
      </RedirectIfAuthed>
    }
  />
  <Route
    path="/login"
    element={
      <RedirectIfAuthed>
        <Login />
      </RedirectIfAuthed>
    }
  />
  <Route path="*" element={<Navigate to={user ? "/" : "/register"} replace />} />
</Routes>


      <div className="container-fluid">
        <div className="row" style={{ height: "calc(100vh - 64px)" }}>
          {/* Map */}
          <div className="col-md-8 p-0" style={{ height: "100%" }}>
            <IncidentsMap
              whenCreated={(map) => (mapRef.current = map)}
              pickMode={pickMode}
              onMapPicked={handleMapPicked}
              pickedLocation={pickedLocation}
              user={user}
            />
          </div>

          {/* Sidebar */}
          <aside className="col-md-4 border-start p-3" style={{ overflow: "auto" }}>
            {/* Add form (gated) */}
            <div className="mb-3">
              <AddIncident
                user={user}
                disabled={!user}
                onRequestPickOnMap={handleRequestPickOnMap}
                pickedLocation={pickedLocation}
              />
            </div>

            {/* الكارد بتاع الفلاتر (لو لسه ما نقلتش الفلاتر للّست) */}
            <div className="card mb-3">
              <div className="card-body">
                <h6 className="card-title">Filter & Sort</h6>

                <label className="form-label small">Severity</label>
                <select
                  className="form-select mb-2"
                  value={severityFilter}
                  onChange={(e) => setSeverityFilter(Number(e.target.value))}
                >
                  <option value={0}>All</option>
                  <option value={1}>≥ 1</option>
                  <option value={2}>≥ 2</option>
                  <option value={3}>≥ 3</option>
                  <option value={4}>≥ 4</option>
                  <option value={5}>= 5</option>
                </select>

                <div className="d-flex gap-2 flex-wrap">
                  <button
                    className={`btn btn-sm ${
                      sortBy === "createdAt_desc" ? "btn-primary" : "btn-outline-secondary"
                    }`}
                    onClick={() => setSortBy("createdAt_desc")}
                  >
                    Newest
                  </button>
                  <button
                    className={`btn btn-sm ${
                      sortBy === "createdAt_asc" ? "btn-primary" : "btn-outline-secondary"
                    }`}
                    onClick={() => setSortBy("createdAt_asc")}
                  >
                    Oldest
                  </button>
                  <button
                    className={`btn btn-sm ${
                      sortBy === "severity_desc" ? "btn-primary" : "btn-outline-secondary"
                    }`}
                    onClick={() => setSortBy("severity_desc")}
                  >
                    Severity ↓
                  </button>
                  <button
                    className={`btn btn-sm ${
                      sortBy === "severity_asc" ? "btn-primary" : "btn-outline-secondary"
                    }`}
                    onClick={() => setSortBy("severity_asc")}
                  >
                    Severity ↑
                  </button>
                  <button
                    className={`btn btn-sm ${
                      sortBy === "severity_and_newest"
                        ? "btn-primary"
                        : "btn-outline-secondary"
                    }`}
                    onClick={() => setSortBy("severity_and_newest")}
                  >
                    Severity ↓ + Newest
                  </button>
                </div>
              </div>
            </div>

            {/* مرّر القيم للّست */}
            <IncidentsList
              onSelectIncident={handleSelectIncident}
              severityFilter={severityFilter}
              sortBy={sortBy}
            />

            {pickMode && <div className="alert alert-info mt-3 p-2">Pick mode</div>}
            {!user && (
              <div className="alert alert-warning mt-3 p-2">
                Log in first to add or delete incidents.
              </div>
            )}
          </aside>
        </div>
      </div>
    </div>
  );
}
