function HomePage({ user }) {
  const mapRef = useRef(null);
  const [pickMode, setPickMode] = useState(false);
  const [pickedLocation, setPickedLocation] = useState(null);
  const [severityFilter, setSeverityFilter] = useState(0);
  const [sortBy, setSortBy] = useState("createdAt_desc");

  function handleRequestPickOnMap() {
    setPickedLocation(null);
    setPickMode(true);
  }
  function handleMapPicked(coords) {
    setPickedLocation(coords);
    setPickMode(false);
    if (mapRef.current && typeof mapRef.current.setView === "function") {
      try { mapRef.current.setView([coords.lat, coords.lng], 15); } catch {}
    }
  }
  function handleSelectIncident(incident) {
    if (!incident?.location) return;
    const { lat, lng } = incident.location;
    if (mapRef.current?.setView) {
      try { mapRef.current.setView([lat, lng], 16); } catch {}
    }
  }

  return (
    <div className="container-fluid">
      <div className="row" style={{ height: "calc(100vh - 64px)" }}>
        <div className="col-md-8 p-0" style={{ height: "100%" }}>
          <IncidentsMap
            whenCreated={(map) => (mapRef.current = map)}
            pickMode={pickMode}
            onMapPicked={handleMapPicked}
            pickedLocation={pickedLocation}
            user={user}
          />
        </div>

        <aside className="col-md-4 border-start p-3" style={{ overflow: "auto" }}>
          <div className="mb-3">
            <AddIncident
              user={user}
              disabled={!user}
              onRequestPickOnMap={handleRequestPickOnMap}
              pickedLocation={pickedLocation}
            />
          </div>

          {/* لو لسه الفلاتر هنا */}
          <div className="card mb-3">
            <div className="card-body">
              <h6 className="card-title">Filter & Sort</h6>
              <label className="form-label small">Severity</label>
              <select className="form-select mb-2" value={severityFilter} onChange={(e)=>setSeverityFilter(Number(e.target.value))}>
                <option value={0}>All</option><option value={1}>≥ 1</option><option value={2}>≥ 2</option>
                <option value={3}>≥ 3</option><option value={4}>≥ 4</option><option value={5}>= 5</option>
              </select>
              <div className="d-flex gap-2 flex-wrap">
                <button className={`btn btn-sm ${sortBy==="createdAt_desc"?"btn-primary":"btn-outline-secondary"}`} onClick={()=>setSortBy("createdAt_desc")}>Newest</button>
                <button className={`btn btn-sm ${sortBy==="createdAt_asc"?"btn-primary":"btn-outline-secondary"}`} onClick={()=>setSortBy("createdAt_asc")}>Oldest</button>
                <button className={`btn btn-sm ${sortBy==="severity_desc"?"btn-primary":"btn-outline-secondary"}`} onClick={()=>setSortBy("severity_desc")}>Severity ↓</button>
                <button className={`btn btn-sm ${sortBy==="severity_asc"?"btn-primary":"btn-outline-secondary"}`} onClick={()=>setSortBy("severity_asc")}>Severity ↑</button>
                <button className={`btn btn-sm ${sortBy==="severity_and_newest"?"btn-primary":"btn-outline-secondary"}`} onClick={()=>setSortBy("severity_and_newest")}>Severity ↓ + Newest</button>
              </div>
            </div>
          </div>

          <IncidentsList
            onSelectIncident={handleSelectIncident}
            severityFilter={severityFilter}
            sortBy={sortBy}
          />

          {pickMode && <div className="alert alert-info mt-3 p-2">Pick mode</div>}
          {!user && <div className="alert alert-warning mt-3 p-2">Log in first to add or delete incidents.</div>}
        </aside>
      </div>
    </div>
  );
}
